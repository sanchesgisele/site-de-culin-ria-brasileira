var nome, dia, mes;//variavel
nome=prompt("Digite seu nome:");
dia=prompt("Digite um dia:");
mes=prompt("Digite um mês:");
if(nome="Celso Portiolli" && dia=="11" && mes=="09"){
    window.alert("O Celso Portiolli não tem nada a ver com o 11 de Setembro")
    }

    else if (nome="gisele" && dia=="17" && mes=="05") {
        window.alert("Faça a prova com atenção");
    }